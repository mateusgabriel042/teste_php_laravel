<?php

namespace App\Imports;

use App\Helper\Helpers;
use App\Http\ApiServices\MeliService;
use App\Models\Product;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\ToCollection;

class ProductImport implements WithHeadingRow, ToCollection
{

    public $provider;
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */

    public function __construct ($provider)
    {
        return $this->provider = $provider;
    }

  
    public function collection($rows)
    {
        $count = 0;
        foreach ($rows as $row) {
            $find = Product::where('id_provider', '=', $this->provider)
                ->where('supplier_product_code', '=', $row['supplier_product_code'])
                ->first();
            if (is_null($find)) {
                $suggestion = (new MeliService())->getCategoryPredictor($row['title']);
                $category = get_object_vars($suggestion['data'][0]);
// dd($category);
                $product = [
                    'title' => $row['title'],
                    'photo' => Helpers::getImages($row['title']),
                    'brand' => $row['brand'] ?? "",
                    'stock' => $row['stock'] ?? 10,
                    'price' => $row['price'],
                    'cat_ml_id' => $category["category_id"],
                    'description' => $row['description'],
                    'condition' => $row['condition'] ?? "new",
                    'id_provider' => $this->provider,
                    'supplier_product_code' => $row['supplier_product_code'],
                ];

                Product::create($product);
                $count++;
                if ($count == 1) {
                    break;
                }
            } else {
                $find->title = $row['title'];
                $find->photo = Helpers::getImages($row['title']);
                $find->stock = $row['stock'] ?? 10;
                $find->price = $row['price'];
                $find->description = $row['description'];
                $find->condition = $row['condition'] ?? "new";
                $find->save();
            }
        }
    }
}
